from django.contrib import admin
#from .models import Test

#admin.site.register(Test)
