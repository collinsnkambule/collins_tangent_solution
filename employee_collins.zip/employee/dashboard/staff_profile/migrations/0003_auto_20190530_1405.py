# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('staff_profile', '0002_test_surname'),
    ]

    operations = [
        migrations.CreateModel(
            name='Employee',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('id_number', models.CharField(max_length=13, blank=True, null=True)),
                ('phone_number', models.CharField(max_length=10, blank=True, null=True)),
                ('physical_address', models.CharField(max_length=200, blank=True, null=True)),
                ('tax_number', models.CharField(max_length=10, blank=True, null=True)),
                ('email', models.EmailField(max_length=254, blank=True, null=True)),
                ('personal_email', models.EmailField(max_length=254, blank=True, null=True)),
                ('github_user', models.CharField(max_length=30, blank=True, null=True)),
                ('birth_date', models.DateTimeField(blank=True, null=True)),
                ('start_date', models.DateTimeField(blank=True, null=True)),
                ('gender', models.CharField(max_length=1, blank=True, null=True, choices=[('M', 'Male'), ('F', 'Female')])),
                ('race', models.CharField(max_length=1, blank=True, null=True, choices=[('A', 'African'), ('W', 'White'), ('I', 'Indian'), ('C', 'Coloured'), ('O', 'Others')])),
                ('creation_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('user', models.ForeignKey(blank=True, null=True, related_name='employee', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'Employee',
                'verbose_name_plural': 'Employees',
                'ordering': ['-id'],
            },
        ),
        migrations.DeleteModel(
            name='Test',
        ),
    ]
